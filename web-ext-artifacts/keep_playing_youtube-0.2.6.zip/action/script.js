document.getElementById('myHeading').style.color = 'green'
